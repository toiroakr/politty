# loculus

Flat schemas for CLI options, HTTP query parameters and text form fields. No runtime dependencies. ESM with TypeScript declarations and [Standard Schema v1](https://standardschema.dev/) validation.

```ts
import * as l from 'loculus';

const query = l.object({
  search: l.string({ trim: true, min: 1 }),
  page: l.number({ integer: true, gte: 1, default: 1 }),
  archived: l.boolean({ default: false }),
  tag: l.array(l.enum(['docs', 'code']), { optional: true }),
});

const params = new URLSearchParams('search=hello&page=2&archived=false&tag=docs');
const value = l.parse(query, l.fromEntries(params));
// value: { search: string; page: number; archived: boolean; tag?: ('docs' | 'code')[] }
```

Use `l.fromEntries(formData)` for FormData. Repeated keys become arrays. Scalar fields reject repeated values, and text fields reject File objects. Values are not silently dropped.

## API

- `string({ min, max, pattern, trim, description, optional })`
- `number({ gt, gte, lt, lte, integer, description, optional })`: strings containing decimal numbers, or finite numbers. Empty strings, whitespace, hexadecimal and Infinity are rejected. `integer` requires safe integers. `gt` / `lt` exclude the boundary; `gte` / `lte` include it. Multiple bounds are combined with AND.
- `boolean({ optional })`: accepts true/false booleans and the strings `"true"`, `"false"`, `"1"`, `"0"`.
- `enum(values, { optional })`, `literal(value)`: string choices.
- `date({ optional })`: ISO calendar dates or ISO date-time strings. Returns a Date.
- `array(fieldOrObject, { min, max, optional, wrapScalar })`: repeated values, or one value. Object schemas can describe rows in a form. Set `wrapScalar: false` to require an array; element conversion still applies. Arrays of arrays and direct object fields are unsupported.
- `{ optional: true }` is supported by string, number, boolean, enum, date and array constructors. Omitted optional object keys are omitted from the output.
- All field constructors, including `literal(value, options)`, support `nullable`, `nullish` and `default`. `nullable: true` preserves null, `optional: true` preserves undefined, and `nullish: true` permits both. Null is never implicitly treated as missing.
- `description` is available in all field constructor options, object options and the final options argument of union, xor, discriminatedUnion and intersection.
- `transform(schema, fn)`, `refine(schema, predicate, message)`.
- Field constructors snapshot their options and array element validators when the schema is created. Later changes to the supplied options do not change an existing schema; referenced regular expressions and default values retain their own identity.

Build with `pnpm build` using tsdown (Rolldown), producing ES2022 ESM and bundled declarations. Schema factories carry `@__NO_SIDE_EFFECTS__` annotations. With Rolldown minification, unused schema construction can disappear without consumer annotations, including nested object fields. This permits skipping construction-time option getters and errors when the schema is unused; do not rely on unused schema construction for side effects. Validation calls (`parse`, `safeParse`, and Standard Schema validation) are not marked pure. `pnpm test` checks the published entry with both esbuild and Rolldown; esbuild still requires call-site `@__PURE__` annotations to remove unused construction. Rolldown without minification retains unannotated construction in the tested cases. Used schemas retain the factories they need.
- `object(shape, { unknownKeys, description })`: `strip` by default; `strict` rejects extra keys; `passthrough` retains them. Only own properties are read. Nested object fields are rejected.

For forms with editable rows, compose an object schema inside an array:

```ts
const item = l.object({ name: l.string({ min: 1 }), quantity: l.number({ integer: true, gte: 1 }) });
const form = l.object({ title: l.string(), items: l.array(item, { wrapScalar: false, min: 1 }) });
```

Use `standardSchemaResolver(form)` with React Hook Form, and distinguish `Input<typeof form>` from the converted `Output<typeof form>`. See the [working React Hook Form example](examples/react-hook-form/README.md), including `useFieldArray`, nested errors, browser tests, and a standalone mobile demo. Native `FormData` field-name parsing is separate; `fromEntries()` does not interpret dotted names.
- `union([a, b, ...], options)`, `xor([a, b, ...], options)`, `discriminatedUnion(key, [a, b, ...], options)`, `intersection(a, b, options)`: compose flat object variants. Intersections reject conflicting output values.
- `safeParse(schema, unknown)`: `{ value }` or `{ issues }`; `parse` throws `ValidationError`. Issues carry paths, including repeated-value indices.
- `Input<typeof schema>` and `Output<typeof schema>` infer types. `_input`, `_output`, and `_optional` are type-only markers, absent at runtime.

Custom transforms and refinements are synchronous. Exceptions from user callbacks propagate to the caller. Default arrays and Dates are shared references; use a transform to produce a fresh value when needed.

## Build-time code generation

`loculus/rolldown` exports an optional build plugin for Rolldown 1.2.13 and tsdown. The runtime entry stays independent of Rolldown.

```ts
import { defineConfig } from 'tsdown';
import { loculusPlugin } from 'loculus/rolldown';

export default defineConfig({
  entry: ['src/main.ts'],
  plugins: [loculusPlugin()],
});
```

Keep writing ordinary schemas and type-checking their original TypeScript. The plugin specializes direct imported `string`, `number`, `boolean`, static scalar-element `array` and static `object` calls. Literal options include string `min`/`max`/`trim`, numeric boundaries and `integer`, descriptions, presence flags, and primitive defaults or default targets. Identical validators are shared within a module; each factory still returns fresh fields, metadata and Standard Schema objects.

Static object shapes preserve frozen snapshots and captured validators while avoiding shape copies, key/validator arrays, and per-field success wrappers. Reads, validation and writes remain interleaved in `Object.keys` order. Own-property input checks, omitted undefined values, issue cloning, `__proto__`, getters, setters and callback behavior are retained. Arrays with direct static scalar children share validators and omit option copies and per-schema validator closures. Array `min`/`max`/`wrapScalar`/`description` literals are supported. Outer presence/default options and dynamic or object children retain ordinary array construction. Native enum, literal, date, transform and refine fields can be captured inside generated objects. Unknown/custom fields, dynamic shapes, getters, spreads and directly nested object fields keep ordinary object construction and validation.

The `objects` option controls the size/speed tradeoff:

- `'auto'` (default): loop over identical runs of at least three fields; split runs of at least 32 fields into functions of eight fixed keys.
- `'loop'`: loop over identical runs of at least two fields, favoring smaller output.
- `'unroll'`: emit each field at a fixed key.
- `'chunked'`: split identical runs of at least eight fields into groups of eight fixed keys.
- `false`: specialize fields (scalars and eligible arrays) without generating object validation.

Use `loculusPlugin({objects: 'loop'})` to prioritize size. No strategy guarantees the fastest result for every engine and input. Dynamic scalar options, regular expressions and unsupported factories retain ordinary validation. Shadowed imports, local built-in names, `eval`, and unsafe syntax are conservatively skipped. The plugin uses Rolldown's native parser and source-map support. It does not execute user schemas during the build. Function identity and source text can change across optimized builds.

There is no runtime `compile`, `eval`, or `new Function` in generated validation code. Fresh and reusable schemas use the same generated output. See [the full measurement protocol and limitations](bench/whole-object/README.md). The React Hook Form demo uses this plugin.

## Presence and defaults

```ts
l.string({ nullable: true }); // string | null; undefined is rejected
l.string({ nullish: true }); // string | null | undefined
l.string({ default: 'guest' }); // undefined -> 'guest'; null is rejected
l.string({ nullable: true, default: 'guest' }); // undefined -> 'guest'; null stays null
l.string({ default: { null: 'guest' } }); // null -> 'guest'; undefined is rejected
l.string({ default: { nullish: 'guest' } }); // undefined and null -> 'guest'
l.string({ default: { undefined: 'guest', null: 'anonymous' } });
l.array(l.string(), { default: ['general'] });
```

Defaults take precedence over presence flags and apply before conversion. They are output values and bypass the field's constraints, outer transforms/refinements still run. Invalid non-nullish inputs and empty strings never trigger a default. `nullish` default targets cannot be combined with `undefined` or `null` targets; conflicting configurations are rejected by types and at construction.

An undefined default makes an object property optional on input and required on output. A null-only default still requires the property on input. Defaults remove null/undefined from the output type only for the targets they replace. Omitting optional/nullish object properties omits them from the output; explicit null is preserved unless a null default replaces it. Array element presence is configured on the element schema separately.

## politty

Use `@politty/loculus` with the same core API as `@politty/zod`:

```ts
import * as l from 'loculus';
import { arg, defineCommand, runMain } from '@politty/loculus';

const serve = defineCommand({
  name: 'serve',
  args: l.object({
    port: arg(l.number({ integer: true, gte: 1, lte: 65535, default: 3000 }), {
      alias: 'p', env: 'PORT', description: 'Listen port',
    }),
    cache: arg(l.boolean({ default: true }), { negation: true }),
  }),
  run: ({ port, cache }) => console.log({ port, cache }),
});
await runMain(serve);
```

## Development and measurement

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm bench
```

The benchmark saves environment, dependency versions, every type-check sample, and runtime medians in `bench/results.json`. See [the measurement protocol](bench/README.md). Performance claims apply only to the measured cases. They do not establish superiority for every expressible schema or every compiler and engine.

Bun 1.4.3 and Node comparisons cover repeated validation, construction plus one validation, process startup, browser bundles, and Bun standalone executables. Loculus uses ordinary schemas; Zod JIT modes are reported separately. See [the Bun protocol](experiments/bun/README.md) and [results](experiments/bun/RESULTS.md). Run `BUN_BIN=/absolute/path/to/bun pnpm bench:bun` to use a specific Bun installation.

## Releases

Library changes use `pnpm changeset`. After merge, the release workflow creates a
version PR; merging it publishes to npm through trusted publishing. See the
[release guide](docs/releasing.md) for initial GitHub App and npm setup.

## MoonBit

The initial implementation uses TypeScript. The JavaScript API needs TypeScript inference, Standard Schema objects and callback support. A MoonBit implementation would still need this binding layer. MoonBit JS and Wasm GC prototypes have now been measured, including JS boundary costs. Neither improved overall throughput or size over TypeScript in the representative cases, so they remain experimental. Run `pnpm bench:moonbit`; see [the experiment and limitations](experiments/moonbit/README.md) and [results](experiments/moonbit/RESULTS.md). They are not shipped in this release.


The optimization comparison preserves the original implementation and compares it with the current build in nine independent Node/Bun processes for every previously identified deficit. The report uses exact permutation tests and Holm adjustment, separates these results from short exploratory timings, and keeps remaining losses visible. See [the measurement protocol](bench/coverage/README.md) and [all results](bench/coverage/RESULTS.md). Absent `meta.optional` and `meta.nullable` flags mean false; adapters should test their truthiness.

The current performance priority is single use: field/schema construction plus one validation, bundle size and type checking. The schema compiler API has been removed, including its per-field preparation. See [the single-use protocol](bench/single-use/README.md) and [the current report](docs/performance-tuning.html). Earlier compiler experiments are [historical evidence](docs/performance-history.html).

The API supports reuse with the same ordinary schema, while performance work prioritizes creation plus one validation. Object shape and validator snapshots, defaults, coercion and callback behavior remain part of the contract.

The [command option benchmarks](bench/cli/README.md) add selected schemas inspired by Git log/clone and Cloudflare cf deploy/DNS records list, each with sparse and densely specified inputs. Their ordinary schemas are included in the single-use measurements, with code for all three libraries, output checks and live browser bundles. Previous compiled measurements are historical.
